#!/bin/bash

if [ "$1" = "-help" ] || [ "$1" = "--help" ]; then
    echo "Uso: $0 [origen] [destino]"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Crea un respaldo comprimido (.tar.gz) con la fecha actual (AAAAMMDD)."
    exit 0
fi

if [ "$#" -ne 2 ]; then
    echo "Error: Debe indicar el directorio de origen y el de destino."
    echo "Use '$0 -help' para obtener más información."
    exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no está disponible."
    exit 3
fi

FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
NOMBRE_BACKUP="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "Backup de $ORIGEN realizado exitosamente en $DESTINO/$NOMBRE_BACKUP"
    exit 0
else
    echo "Error al generar el backup de $ORIGEN."
    exit 4
fi
