 poweroff
 poweroff
sudo hostnamectl set-hostname TPServer
hostnamectl
sudo nano /etc/hosts
hostnamectl
nano /etc/hosts
vi /etc/hosts
hostnamectl
apt-get install openssh-server
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt-get install openssh-server
vi /etc/apt/sources.list
apt-get install openssh-server
apt update
reboot
apt update
apt full-upgrade
apt-get install openssh-server
apt update openssh-server
apt full-upgrade
apt-get install openssh-server
apt update
poweroff
apt updddate
apt update
apt update
apt upgrade
clear
apt update
apt update
apt'get install openssh'server
apt-get install openssh-server
apt-get install openssh-server
apt install ssh
cat /etc/os-release
vi /etc/apt/source.list
vi /etc/apt/sources.list
apt install ssh
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
systemctl restart networking
ip a
ifup /dev/enp0s3
ip a
ifup enp0s3
ip a
apt update
apt install openssh-server 
ls -la
ch /.ssh
cd /.ssh
ip a
mkdir -p /.ssh
ls -la
mkdir -p /.ssh
apt install nano
nano /.ssh/authorized_keys
systemctl restart networking
ip a
ifup enp0s3
ifup enp0s3
ip a
systemctl restart networking
ifup enp0s3
ip a
ip a
systemctl restart 
systemctl restart 
systemctl reboot 
ip a
apt update
apt-get install openssh-server 
ls la
ls
ls a
la
ls
ls
ls -la
find ssh
find ssh_config
apt upgrade
sudo nano /etc/ssh/sshd_config
sudo systemctl restart ssh
poweroff
sudo systemctl status ssh
ip a
sudo allow ssh
sudo ufw allow ssh
sudo nano /etc/network/interfaces
sudo dhclient -r enp0s3
sudo dhclient enp0s3
ip a
sudo systemctl status ssh
sudo systemctl restart networking
ip a
sudo ip link set enp0s3 up
sudo dhclient enp0s3 
ip a
sudo nano /etc/network/interfaces
sudo ip link set enp0s3 up
sudo systemctl restart networking
ip a
sudo poweroff 
cat /etc/network/interfaces
sudo nano /etc/network/interfaces
sudo systemctl restart networking
sudo nano /etc/network/interfaces
sudo systemctl restart networking
ip a
poweroff 
ip a
poweroff 
cd &.ssh
cd /.ssh
nano ~/.ssh/authorized_keys
nano authorized_keys
cd ..
chmod 600 ~/.ssh/authorized_keys
chmod 600 /.ssh/authorized_keys
sudo nano /etc/ssh/sshd_config
sudo systemctl restart ssh
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
apt update
apt install apache2 php libapache2-mod-php -y
systemctl enable --now apache2
systemctl status apache2
sudo apt install php-mysql -y
sudo systemctl restart apache2
sudo systemctl restart apache2
sudo nano /var/www/html/index.php
sudo systemctl restart apache2
apt install apache2
sudo apt install mariadb-server -y
apt update
apt install mariadb-server -y
systemctl enable --now mariadb
mysql -u root < /root/db.sql
poweroff 
ip a
lsblk
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir
mkdir -p /backup_dir
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
systemctl restart apache2
blkid /dev/sdc1
blkid /dev/sdc2
nano /etc/fstab
nano /etc/fstab
1+
fg
mount -a
cat /proc/partitions > /proc/particion
ls -l /www_dir
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -l /www_dir
df -h
mkdir -p /opt/scripts
nano /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
crontab -e
/opt/scripts/backup_full.sh /var/log /backup_dir
nano /opt/scripts/backup_full.sh
fg
/opt/scripts/backup_full.sh /var/log /backup_dir
cat << 'EOF' > /opt/scripts/backup_full.sh
#!/bin/bash

if [ "$1" = "-help" ] || [ "$1" = "--help" ]; then
    echo "Uso: $0 [origen] [destino]"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Crea un respaldo comprimido (.tar.gz) con la fecha actual (AAAAMMDD)."
    exit 0
fi

if [ "$#" -ne 2 ]; then
    echo "Error: Debe indicar el directorio de origen y el de destino."
    echo "Use '$0 -help' para obtener más información."
    exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no está disponible."
    exit 3
fi

FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
NOMBRE_BACKUP="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "Backup de $ORIGEN realizado exitosamente en $DESTINO/$NOMBRE_BACKUP"
    exit 0
else
    echo "Error al generar el backup de $ORIGEN."
    exit 4
fi
EOF

/opt/scripts/backup_full.sh /var/log /backup_dir
ls -l /backup_dir
nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -l /backup_dir
poweroff 
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
nano /etc/ssh/sshd_config
mkdir -p ~/.ssh
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
ls -la /root/.ssh/
cat /root/.ssh/authorized_keys
ls -la
cd /.ssh/
ls -la
cat authorized_keys 
ssh-keygen -lf /.ssh/authorized_keys
sshd -T | grep authorizedkeysfile
cd ..
cp /.ssh/authorized_keys /root/.ssh/authorized_keys
chown root:root /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
